━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PERSONAL AUTHORITY FOUNDATION
Voice DNA Document — English
Client: Ina · June 2026
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# VOICE DNA DOCUMENT
## Ina

Sources: 15 intake answers + coaching transcript (Kathrin call)

---

## SECTION 1: CONVERSATIONAL MARKERS

**Primary fillers — heavy user (every 2–3 sentences in German originals):**

When writing English content, these German speech patterns translate into specific English equivalents:

- **"irgendwie" → "somehow" / "in some way"** — her hedging marker when still thinking through something
- **"eigentlich" → "actually" / "really"** — correction signal; she says one thing, then gives the more honest version
- **"ich glaube" → "I think" / "I believe"** — thinking aloud, not weakness; she marks provisional claims
- **"halt" → rhythm filler, omit in English** — no direct equivalent; restructure the sentence

**Transition phrases (English equivalents):**

- "At the same time..." — her go-to for holding two truths in tension
- "And that's when..." — narrative time jump
- "That's the difference." — closing a contrast structure
- "The bottom line is..." — [characteristic, not recurring]

**Sentence openers:**

1. Direct statement with no warm-up ("They know what they can do.")
2. "I think..." or "I believe..." — provisional framing before a stronger claim
3. "That's..." / "It was..." — situation-as-opener

---

## SECTION 2: SENTENCE PATTERNS

**Average length:** 12–18 words, but varies strongly.

**Preferred structures:**

- **Short declarations (5–8 words):** Her natural closing move.
  > "I practice what I preach."
  > "They know what they can do."
  > "That was right. That was good."

- **Mid-length explanatory sentences (10–15 words):**
  > "I translate it into plain language, using frameworks only when they're genuinely needed."

- **Longer flowing thoughts (16+ words):** At moments of analysis or reflection.
  > "When people are being especially friendly and want something from you — slow down and think through the consequences before you act."

- **Self-correction mid-sentence** — says something, immediately pulls it back, gives the more honest version.
  > "That's not quite right — but you feel the pressure differently, and over the years it makes itself known physically, mentally, emotionally."

**Sentence variety:** Strongly varied. Never monotone. Short → long → short is her natural rhythm.

**Most common openers:** Direct statement / "I think" / "That was"

---

## SECTION 3: VOCABULARY PROFILE

**Technical comfort level: 3/5**

Full command of HR, organizational, and coaching terminology — uses it sparingly and only in context. Never to impress. Her explicit position: "I have the competence, I know all of it — but I translate it into plain language."

**Terms she uses naturally without explanation:**

| Term | Context |
|---|---|
| Org design | Her core work |
| M&A integration | Positioning |
| Change management | Service description |
| Business partner | Career conversation |
| Unwritten rules | Political navigation |
| Accountability | Coaching outcome |
| Plan B | Strategic career thinking |
| Pain point | AI & coaching analysis |
| Reactive vs. proactive | Core distinction she draws repeatedly |
| Self-reliance | Core value and coaching outcome |

**Reading level:** Grade 8–9. Direct, accessible without being simple. Occasional informality. No academic distancing.

**Unique vocabulary (English equivalent patterns):**

- "no filler, no buzzwords" — explicit rejection of corporate language
- "pragmatic, efficient, results-focused" — her self-description as a triad
- "cut straight through the heart" — emotional intensity, used rarely and therefore landing hard
- "what doesn't kill you makes you tougher" — she quotes this unironically; she means it
- "they know what they can do, and they know how to get it" — her description of the outcome she delivers

---

## SECTION 4: EMOTIONAL SIGNATURE

**Primary tone: Direct-Reflective**

Not emotionally charged, not cold. She reflects out loud, names feelings precisely without dwelling in them, and returns to the factual level.

> "That cut straight through the heart. [...] But it actually motivated me to keep going even harder."

**Secondary tone (under challenge): Dry-pragmatic**

When things get hard, the emotional expression flattens. She analyzes rather than complains.

> "I was perfectly capable of making competent decisions that turned out to be right. I just went against the process."
> Transcript: "That's not much fun anymore, let's put it that way."

**Tonal shifts:**

- Personal topics (loss, relationships): short precise sentences, quick return to analysis
- Professional topics: matter-of-fact, occasionally dry-ironic
- Values: noticeably warmer, more certain, more conviction

**Confidence markers:**

When certain: direct statement, no hedging.
> "They know what they can do, and they know how to get it."
> "When success comes with ease, it's done right."

When uncertain: "I think" + tentative + self-correction.
> "I'm not sure whether that's what drives my decisions. I don't think so."

---

## SECTION 5: TOP 10 SIGNATURE PHRASES (English versions)

**1. "pragmatic, efficient, results-focused"**
- Context: Self-description of working method
- English use: "I work pragmatically, efficiently, results-focused — no filler, no buzzwords."
- Professional ✓

**2. "no filler, no buzzwords"**
- Context: How she differentiates from others
- English use: "I don't throw jargon at you to sound impressive."
- Professional ✓

**3. "reactive instead of proactive"**
- Context: Core critique of people and organizations
- English use: "Most people don't reflect. They arrange themselves with whatever comes their way and live reactively."
- Professional ✓

**4. "motivated me even more"**
- Context: Response pattern to setbacks, being overlooked, failure
- English use: "Not being seen actually motivated me to push harder."
- Professional + Story ✓

**5. "I practice what I preach"**
- Context: Congruence between words and actions — said in English even in German answers; signals conviction
- Professional (as closer) ✓

**6. "immediately actionable"**
- Context: What distinguishes her work
- English use: "Practical, hands-on, immediately actionable."
- Professional ✓

**7. "when success comes with ease, it's done right"**
- Context: Redefinition of success
- Strong standalone statement ✓
- Professional + Content ✓

**8. "actually listen / really hear"**
- Context: What people and organizations consistently fail to do
- English use: "Just actually listen to what someone is saying before you react."
- Professional ✓

**9. "that was simply right"**
- Context: Retrospective verdict on a tough decision — she draws clean conclusions
- English use: "Walking away was simply the right call."
- Story + Casual ✓

**10. Triad structure** (characteristic)
- Context: When describing her core territory, triads emerge naturally
- Examples: "freedom, respect, self-reliance" / "pragmatic, efficient, results-focused" / "their qualities, their expertise, their competence"
- Professional ✓

---

## SECTION 6: IDEA FLOW PATTERN

**Dominant pattern: Personal experience → Observation → Universal principle**

Always from the concrete to the general. Never the reverse.

> "At work, I made decisions that were factually right — but went against process. It cost me a role temporarily. What followed was significantly better. The lesson: slow down before acting, especially when people are being unusually friendly and want something from you."

**Credibility building:** Through results + what it actually cost. She shows the price of decisions and what they produced. No abstract claims.

**Handling complexity:** Through examples and contrast. She doesn't explain theory — she shows situations. When she abstracts, an example follows immediately.

**Closing a thought:** Direct verdict or clean statement — she doesn't leave things hanging.
> "It was simply right."
> "That's when I knew: this is my thing."

---

## SECTION 7: AUTHENTICITY MARKERS

**Communication quirks:**

1. **Mid-sentence self-correction** — says something, immediately gives the more honest version.
   > "That's not quite right — but over the years it makes itself known physically, mentally, emotionally."

2. **English inserts for precision** — when a German word isn't strong enough, she switches.
   > "I practice what I preach." / "unwritten rules" / "Plan B" / "pain point"
   In English content: she'll occasionally use a German phrase for texture — use sparingly.

3. **Natural triads** — not a stylistic device; it just happens.
   > "freedom, respect, self-reliance" / "physical, mental, emotional" / "their qualities, their expertise, their competence"

4. **States uncertainty openly, then continues anyway.**
   > "I'm not sure that's it — but usually I..."
   > "Nothing specific comes to mind right now, but typically..."

5. **Contrast structure** — "not X, but Y" or "yes X, but not when it comes to Y"
   > "I have the competence and I know all of it — but I translate it into plain language."
   > "I do doubt sometimes and can be persuaded — but not on the things that really matter."

6. **Emotional brevity, then rationalization** — feelings named, not expanded.
   > "That cut straight through the heart. [...] But it motivated me to keep going."

**Perspective patterns:**

1. **Freedom as the primary decision variable** — when choosing between security and freedom, freedom wins
2. **Results over process** — she evaluates actions by output, not rule compliance
3. **People are accountable for themselves** — the real change always comes from the client, not from her
4. **Ease as a success indicator** — grinding yourself to exhaustion means something is miscalibrated

**Personal touches:**

- Speaks of pets with genuine grief ("cut straight through the heart")
- References specific moments: the café with friends, particular videos, concrete jobs
- Uses the body as feedback system: "physically, mentally, emotionally"
- Transcript: cats as a warmth signal — she builds real connection through personal detail

**Values that come through:**

- **Freedom** — "The value is actually freedom, respect, independence, self-reliance."
- **Honesty** — she corrects herself mid-sentence rather than keeping a cleaner version
- **Competence without performance** — "I have the competence" — always grounded in a situation, never in self-promotion
- **Accountability** — lived personally, delivered as an outcome to clients

---

## SECTION 8: RED FLAGS — WHAT SHE'D NEVER SAY

**Language she avoids:**

- Buzzwords: transformation, journey, empower, holistic, leverage, unlock, ecosystem, synergy, navigate
- Academically distanced: "Evidence suggests that..." / "Research indicates..."
- Moralizing: "One should..." / "It's important to..."
- Hype language: game-changer, disruptive, next-level, crushing it

**Specific violations:**

✗ NEVER write: "I help you unlock your full potential."
   Why: Empty promise, no mechanism — exactly what she criticizes in others

✗ NEVER write: "On this transformative journey..."
   Why: "transformation" and "journey" are the exact buzzwords she explicitly rejects

✗ NEVER write: "My holistic approach..."
   Why: She rejects all methodology-posing; she works concretely, not holistically

✗ NEVER write: "I offer tailored solutions for your unique needs."
   Why: Corporate filler — "filler and buzzwords" in her own words

✗ NEVER write: "As a passionate mentor..."
   Why: Adjective-stacking contradicts her plainness and directness

✗ NEVER write: Any motivational cliché ("you've got this", "step into your power")
   Why: Exactly the kind of empty phrasing she'd find cringeworthy

✗ NEVER write: Three bullet points with no situational context before them
   Why: She always explains the situation first — lists without ground feel like copy-paste

✗ NEVER write: "I am delighted to inform you..." or any formal throat-clearing
   Why: Formality that doesn't fit her directness

**Structural violations:**

- Never open with an abstract thesis — always open with a concrete situation or observation
- Never stack adjectives — she describes through verbs and situations, not properties
- Never self-praise without counterweight — she names strengths in the context of challenge or cost

---

## CLAUDE ACTIVATION KEY

```
VOICE ACTIVATION — INA (English content)

You are writing LinkedIn posts and brand copy for Ina —
Interim HR Executive, Org Design, M&A, Restructuring, Coaching.

Voice in one sentence: Direct, pragmatic, reflective —
no pose, no buzzwords, full competence made visible
through clarity rather than performance.

Rules:
1. Sentence rhythm: Short statement → longer explanation → short verdict.
   Never three long sentences in a row. Strong natural variation.
   Triads appear organically — don't force them, don't suppress them.

2. Vocabulary: Plain English. Technical terms only in context, never
   to impress. Grade 8–9 reading level. Occasional informality is fine.
   No academic distancing.

3. Emotional register: Direct-reflective. Name feelings briefly, then
   move. Never plaintive, never hyped. Dry-ironic under pressure.
   Clean and almost matter-of-fact for conclusions.

4. Always include:
   - Concrete situation BEFORE any principle or statement
   - Freedom / accountability as implicit values
   - Contrast structure ("not X, but Y")
   - Clean verdict at the end

5. Never write:
   - "transformation", "journey", "holistic", "empower", "unlock"
   - Adjective stacks without situational context
   - Abstract promises without mechanism
   - Bullet lists without a situational lead-in
   - Corporate filler or motivational clichés

6. Idea flow: Concrete situation → personal observation →
   universal principle. Never the reverse.

7. Proof style: Results + what they actually cost.
   Real situations, not claims. Client outcomes as evidence,
   not credentials.
```

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PERSONAL AUTHORITY FOUNDATION · Purely Personal
