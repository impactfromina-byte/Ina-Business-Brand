━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
BUSINESS AUTHORITY FOUNDATION
Business Inbox
Client: Ina Spuling · Impact von Ina · June 2026
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# BUSINESS INBOX
## Ina Spuling

*Navigation: Brand strategy → other documents | This document → factual business data only*

---

## SECTION 1: BUSINESS FOUNDATION

**Business/Brand name:** Impact von Ina
**What they do in plain language:** Executive career coaching and leadership advisory for senior professionals. Ina combines 22+ years of first-hand HR executive experience with individual coaching to help high performers make concrete decisions about their next move — and execute them. She also offers corporate advisory for organisations that want pragmatic HR/people strategy without a large consulting firm.
**Stage:** Building — existing coaching practice, now deliberately pivoting toward coaching/consulting/speaking as primary revenue, with corporate advisory as the premium track
**Location/markets:** Germany (DACH primary), internationally mobile, English and German language delivery
**Revenue streams:** 1:1 executive coaching, group coaching programs, corporate advisory/consulting (project-based), speaking (building)

---

## SECTION 2: OFFER INVENTORY

### Offer 1: Group Coaching Program
- **What it is:** Structured 6-week program for high performers navigating career decisions
- **Who it's for:** Senior professionals with a concrete career challenge (next move, leadership transition, freelance/founding decision)
- **What it delivers:** Clarity on what they want + insider roadmap + peer accountability from a small cohort of people in similar situations
- **How it works:** Bi-weekly group sessions (every 1–2 weeks), max 10 participants, led by Ina
- **Duration/scope:** 6 weeks
- **Price:** €2,000–2,500 per participant
- **Status:** Idea stage / in development

### Offer 2: 1:1 Executive Coaching
- **What it is:** Individual coaching sessions combining career strategy, insider corporate knowledge, and accountability
- **Who it's for:** Senior professionals who want private, direct, personalised work — often with a specific high-stakes decision or transition
- **What it delivers:** Concrete plan + insider knowledge + momentum
- **How it works:** 5–6 sessions (typical engagement); option for ongoing accountability (every 2 weeks, 30 min)
- **Duration/scope:** 5–6 sessions + optional ongoing check-ins quarterly or bi-weekly
- **Price:** €400–500/hour
- **Status:** Active

### Offer 3: Corporate Advisory (Project-Based)
- **What it is:** Pragmatic people/HR strategy for organisations — not as an ongoing interim manager but as a project-based expert who goes in, builds the strategy, enables the team, and exits
- **Who it's for:** Companies that need real HR/OD thinking without a large consulting firm (M&A integration, restructuring, org design, change management, leadership development)
- **What it delivers:** Strategy + team enablement + sustainable implementation
- **How it works:** Project-scoped engagement; Ina comes in, delivers, trains the internal team to carry it forward
- **Duration/scope:** Project-based (scope varies)
- **Price:** [NEEDS MORE INFO: day rate / project rate for corporate advisory not specified]
- **Status:** Active (currently positioned partly as interim; repositioning toward advisory)

### Offer 4: Speaking
- **What it is:** Keynotes and panel appearances on career, leadership, corporate culture, AI + the workforce
- **Who it's for:** Corporate events, HR conferences, leadership summits
- **What it delivers:** Insider perspective with practical takeaways — no theoretical fluff
- **Price:** [NEEDS MORE INFO: speaking fee not specified]
- **Status:** Building

### Offer Flow
Speaking (visibility) → LinkedIn content (credibility) → Corporate Advisory or 1:1 Coaching (revenue) → Group Program (scale)

---

## SECTION 3: HOW DELIVERY WORKS

**1:1 Coaching Process:**
1. First conversation — real-talk status analysis: What's actually going on? What does the person really want?
2. Sessions 2–4: Unpacking what's underneath, mapping the real landscape with insider knowledge, identifying the actual next move and the specific path to it
3. Sessions 5–6: Building and executing the plan — application, positioning, approach, conversation strategy, timing
4. Optional: Ongoing accountability (bi-weekly 30-min check-ins) or quarterly reviews

**Approach characteristics:**
- No lengthy questionnaires or diagnostic tools
- Intuition-led but grounded in 22+ years of pattern recognition
- Highly individualised — the process adapts to the person and situation
- Results-oriented: every session ends with something concrete
- Direct and warm — challenged and supported simultaneously

---

## SECTION 4: PROOF & CREDIBILITY

### Results & Case Stories

**Story 1 — The Sales Leader Who Became a Manager:**
- Before: Senior sales professional eager to move into leadership with a team
- What was done: Clarified what the management role actually involves day-to-day (Excel, forecasting, internal meetings) versus what he had been doing (direct client contact, deals, relationships)
- After: Made an informed decision — either to pursue leadership with full awareness of what it meant, or to reposition toward a senior individual contributor path that played to his actual strengths
- Why it matters: Prevented a costly, demoralising mistake made by going in blind

**Story 2 — The Controller Who Ended Up in Strategy:**
- Before: Finance expert who became a manager — and found himself in endless strategy meetings instead of the numbers work he actually loved
- What was done: Named the mismatch between the role's reality and his actual motivation; mapped what a more aligned path looked like
- After: Clarity on what he wanted from the next move — and what to look for / negotiate before taking a leadership role again

### Authority Indicators
- **Time doing this work:** 22+ years in HR and people leadership
- **People coached:** 1,000+ (a mix of formal and informal, individual and group)
- **Leaders worked with:** 100+
- **Industries:** IT (primary), Cyber Security, multiple sectors across startup to enterprise
- **Levels reached:** Admin through VP/Interim Head; Director; Interim HR Executive
- **Published:** Book (*Quick Guide Zeitgemäßes Personalmanagement*); second book in progress (*Personalmanagement für Chefs*, MVG Verlag)
- **Coaching credential:** [NEEDS MORE INFO: formal coaching certification not specified — confirm if/what to name]

---

## SECTION 5: BUSINESS HISTORY

**How it started:** Built from 22+ years inside organisations — HR executive across industries and company sizes, with coaching always embedded in the role (formal and informal). Coaching competency developed internally before formalised as an external offer.
**Current state:** Operating as a hybrid interim HR executive and career/executive coach; actively repositioning toward coaching, consulting, and speaking as primary model — with corporate advisory evolving from time-based interim to project/advisory model.
**Key pivot:** Moving from "selling time as an interim manager" toward building a brand and business that scales through content, reputation, and advisory engagements — LinkedIn as the primary distribution channel.

---

## SECTION 6: VISUAL BRAND IDENTITY

**Brand colors:**
- Primary/Dark: Navy — #1A1A2E
- Secondary/Accent: Gold — #C9A96E
- Note: Colors confirmed from prior brand development work; Ina confirmed these

**Typography:**
- Heading font: Cormorant Garamond (confirmed from prior brand work)
- Body font: Lato (confirmed from prior brand work)

**Aesthetic description (in her words):** "Warm-kompetent, humorvoll, umsetzungsstark" — the visual translation: the warmth of something accessible, the sharpness of something professional, the authority of something that has been built over time. Navy + gold communicates credibility without coldness.

**Current brand assets:**
- LinkedIn profile (active, building)
- Website domains: inaspuling-yourmentor.de (coaching); [corporate site — confirm URL]
- SVG quote-card graphics developed (navy and gold)
- Book (*Quick Guide Zeitgemäßes Personalmanagement*) as authority asset

---

## SECTION 7: ONLINE PRESENCE

**Website:** inaspuling-yourmentor.de (coaching); corporate advisory site [NEEDS MORE INFO: confirm second domain/URL]
**LinkedIn:** Active — 1,000+ connections, has commented and liked but never posted; now starting content strategy
**Other platforms:** [NEEDS MORE INFO: Substack (*Career Recode*) — confirm current status/activity level]
**Current content activity:** Just starting. LinkedIn is the primary channel. Zero prior posting history.

---

## SECTION 8: REVENUE & GOALS

**Average offer price:** €400–500/hr (1:1); €2,000–2,500 per participant (group)
**Monthly revenue target:** [NEEDS MORE INFO: no explicit monthly target stated]
**Clients needed per month (indicative):**
- 1:1 only: ~4–6 active coaching clients at 5–6 sessions each covers a solid base
- Group program: 8–10 participants per cohort; 2–3 cohorts/year = significant supplementary revenue
**Primary LinkedIn goal:** Build visibility as the corporate insider for high performers; attract both individual coaching clients and corporate advisory conversations
**Timeline:** Next 3–6 months = LinkedIn content engine live + group program structure finalised + corporate advisory repositioning underway

---

## SECTION 9: COMMUNICATION GUIDELINES

**Tone by context:**
- LinkedIn posts: Direct, insider, specific — challenges a conventional belief or names something everyone experiences but nobody says out loud. Always ends with something the reader can do or think differently about.
- Sales conversations: No pitch. Real conversation. She names what's actually happening for the person before they've fully explained it — that's the trust signal.
- Client onboarding: Sets expectations clearly and directly — this is how we work, this is what you'll have to do, this is what you get. No fluff.

**Language to use:**
Klarheit — konkret — Mechanismen — von innen heraus — Insider-Know-how — Shortcut — Macher — pragmatisch — Resultate — Entscheidung — Durchsetzung — Eigenverantwortung — ehrlich — schnell — umsetzungsstark

**Language to avoid:**
Transformation — Journey — Empower — Unlock — Holistic — Ecosystem — Navigate — Synergy — Ganzheitlich — Potenzial entfalten — Augenhöhe (overused in German coaching) — "auf Augenhöhe" — anything that sounds like a personal development brochure or a course sales page

**Hard limits:**
- No AI-generated applications or generic templates offered to clients
- No personality tests as the primary diagnostic tool
- No positioning as "another career coach" — always anchor to the insider access first
- Won't work with people who don't have the will to act — not a therapy substitute

---

## SECTION 10: LINKEDIN & CONTENT PRIORITIES

**LinkedIn goal:** Establish Ina as the go-to corporate insider voice for senior professionals in DACH (and internationally); attract 1:1 coaching clients and corporate advisory conversations organically; build toward a speaking pipeline

**Content themes:**
- The truth about how corporate decisions really get made (promotions, restructurings, leadership selections)
- What career coaches get wrong because they've never been inside
- The title trap — why the role you want might not be the job you'd love
- Taking ownership of your own career rather than waiting for your employer to develop you
- AI and the workforce — what's actually changing vs. the noise
- Leadership from the inside — what good management actually looks like vs. what it says in books

**Formats:** Text posts (starting) + comments on others' posts (active already) + potentially speaking clips once that track builds

**Current posting status:** Not yet started — first posts being built now

**Upcoming:**
- Group coaching program: design and launch
- Corporate advisory: repositioning from time-based interim to project/advisory model
- Speaking: active pipeline building
- LinkedIn: content engine as primary distribution mechanism for all of the above
