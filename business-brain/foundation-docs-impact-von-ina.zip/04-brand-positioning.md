━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
BUSINESS AUTHORITY FOUNDATION
Brand Positioning
Client: Ina Spuling · Impact von Ina · June 2026
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# BRAND POSITIONING
## Ina Spuling

---

## CATEGORY DEFINITION

**You are not:**
- A career coach with a certification and a framework
- A recruiter who knows "the market"
- A management consultant who restructures from the outside
- A trainer who delivers skills programmes in day-long workshops

**You operate as:**
The Corporate Insider who translates how organisations actually work — and uses that to help high performers make better, faster, more informed decisions about their own careers and leadership.

**This shifts the category from:** "Career Coaching"
**To:** "Corporate Insider Access for High Performers"

---

## COMPETITIVE LANDSCAPE

**Who else is in this space:**
Generic career coaches, executive coaches with consulting backgrounds, LinkedIn gurus, recruiters positioning as advisors, Outplacement firms, leadership development companies, and the vast library of self-help career books.

**What they offer:**
Frameworks, tools, personality assessments, networking advice, CV polishing, LinkedIn optimisation, and theory about leadership — mostly from the outside of the organisations their clients actually work in.

**The gap they leave open:**
Nobody in this space can say they've been inside as many different organisations, at as many different levels, across as many different functions, as an HR executive — and can therefore decode how that specific system works for that specific person. The insider translation is the gap. Everyone else is working from observation. Ina is working from participation.

---

## STRATEGIC ANCHORS

**Frame of Reference:** Executive Career Advisor with Corporate Insider Access

**Point of Difference (POD):**
22+ years of direct experience inside organisations as an HR executive — advising leaders, managing restructurings, watching promotions happen, coaching through M&A — across company sizes from startup to enterprise. This is not knowledge about companies. It is knowledge from inside them. No other career coach in this space can claim the same scope of first-person operational access.

**Point of Parity (POP):**
Coaching certification and methodology, empathy and genuine care for the client, confidentiality, and the ability to help a client clarify their goals and build a plan.

**Strategic Sacrifice:**
- Not for people who want someone to blame for where they are
- Not for people who are not prepared to invest in themselves (financially or in terms of action)
- Not for generic "I want a better work-life balance" coaching without a concrete next move
- Not corporate L&D departments looking for a trainer to deliver a programme to 50 people
- Not interested in being positioned as an interim manager (time-for-money model) any more than necessary

---

## THE CORE POSITIONING TERRITORY

"Ina Spuling is the go-to advisor
for high performers who've built something real inside corporate life
and now need someone who actually knows how that world works
to help them decide — and execute — what comes next."

---

## FORMAL POSITIONING STATEMENT

For senior professionals and high performers
who know they want to move but can't figure out how the system actually works in their favour,
Ina Spuling is the corporate insider turned executive coach
who translates what nobody inside your company will tell you to your face,
unlike coaches who advise on corporate life without ever having been inside it,
because she spent 22+ years as an HR executive inside the rooms where the decisions about people's careers actually get made.

---

## BRAND ARCHITECTURE

**Brand Promise:**
"Ina Spuling promises her clients will leave with a concrete next move they chose, a plan they can execute, and the insider knowledge to make it land — faster than they thought possible."

**Brand Essence:** Insider. Direct. Warme Klarheit. *(Warm Clarity)*

**Brand Archetype:** The Mentor — with the credibility of the Sage
- **Why:** Ina has built her insight through 22+ years of lived experience across organisations, not through study alone. She brings both the warmth of someone who genuinely cares and the authority of someone who has been inside.
- **How it shows up:**
  1. She tells clients what nobody inside their company will say — the truth about how decisions are actually made, what the promotion conversation really looks like, why they actually didn't get the role.
  2. She insists on ownership: the client is the one who has to move. She creates the clarity and the plan; they execute. That combination of care and challenge is the mentor archetype in action.

---

## TAGLINE OPTIONS

**Category-owning:**
1. The Corporate Insider.
2. Career Clarity. From the Inside.

**Differentiation-first:**
3. What no career coach will tell you — because they've never been inside.
4. The shortcut is someone who's already been there.

**Transformation-focused:**
5. From stuck to moving. Faster than you think.
6. Get in. Decide. Move.
7. The next chapter is yours to write. Let's start.

**Recommended:** Option 1 — *The Corporate Insider.* — because it owns the positioning claim directly, says everything in three words, and is impossible for a competitor to copy without lying. It also travels cleanly across German and English contexts.

---

## STRATEGIC DO'S AND DON'TS

**DO:**
1. Lead with the insider credential — in every introduction, headline, and piece of content
2. Use specific corporate situations and real examples — this is the proof that you were actually inside
3. Name what doesn't work about other solutions (books, generic coaching, recruiters) — specifically, not broadly
4. Show the practical outputs: what does a client actually have after working with you?
5. Speak directly to the person who funds this themselves — frame it as an investment in their own agency

**DON'T:**
1. Position as another career coach — always anchor to the corporate insider angle first
2. Use buzzwords that belong to the coaching world you're differentiating from (transformation, journey, empower, unlock)
3. Try to serve everyone — the strategic sacrifice is real: people without the will to act are not your client
4. Compete on warmth and empathy alone — that's table stakes; the differentiation is always insider access + practical results
5. Go back to selling time as an interim manager without strategic intent — every engagement should move the brand toward advisory, not execution

---

## THE STRATEGIC ENEMY

"Ina Spuling's true opponent is the belief that your career path is something that happens to you —
not the recruiter who didn't call back, not the colleague who got the promotion,
but the quiet acceptance that the system is in charge and you are inside it."

That belief — that the corporate world is something you navigate rather than something you can decode and work — is what keeps Ina's ideal clients stuck. Her entire practice is a counter-argument to it.

---

## POSITIONING NARRATIVE
*(For pitches, introductions, and partnerships)*

Impact von Ina exists because the people who've contributed the most to organisations are often the least equipped to navigate their own next chapter — not because they're not capable, but because nobody ever explained how the system actually works from the inside.

Ina Spuling believes that insider knowledge is not a luxury — it's what separates a good decision from a decade of the wrong ones.

Unlike career coaches who advise on corporate life from the outside, Ina spent 22+ years inside organisations as an HR executive — advising leaders, managing the human side of restructurings, coaching across functions and company sizes, in one of the most demanding sectors in business.

This makes her the go-to advisor for senior professionals and high performers who need someone who knows what's really happening inside the room — and can help them use that knowledge to move.

Proven through more than 1,000 people coached and more than 100 leaders worked with — not theoretically, but in the room, in the crisis, in the conversation that mattered.
