━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
BUSINESS AUTHORITY FOUNDATION
Messaging House
Client: Ina Spuling · Impact von Ina · June 2026
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# MESSAGING HOUSE
## Ina Spuling

---

## FOUNDATION

**The Central Tension:**
High performers have been so focused on achieving what was expected of them that they've never stopped to decide what they actually want. Now they're stuck — successful by most measures, directionless by their own. They have the drive, the experience, and the credentials. What they don't have is someone who can tell them the truth about how the system works and help them move through it faster.

**The Unique Messaging Angle:**
Ina has been inside the room. Not as a recruiter seeing the outside, not as a trainer delivering frameworks from a manual — as the HR executive who coached the leaders, managed the restructurings, watched promotions get made and blocked, and saw exactly why people advance or stall. That insider access is the product. Nobody else in the career coaching space can honestly claim it at this level of scope and depth.

---

## UNIQUE VALUE PROPOSITION

**Short (12 words):**
Career clarity and a real plan — from someone who's been inside.

**Medium (30 words):**
Ina Spuling combines 22+ years of corporate HR leadership with executive coaching to help high performers cut through the noise, understand how the system actually works, and make their next move with confidence.

**Long (65 words):**
Most career coaches give you frameworks. Ina gives you the truth. After 22+ years inside companies of every size — advising leaders, shaping cultures, watching decisions get made — she knows what actually moves the needle for people who've already proved themselves. She works with high performers who are stuck, burned out, or unsure of what's next, and gets them to a clear decision and a working plan — fast, practical, and no nonsense.

*UVP test: Could a generic career coach say this? No. The specific claim of 22+ years inside HR — coaching leaders, managing restructurings, witnessing how promotions actually happen — is not replicable.*

---

## MESSAGING PILLARS

### Pillar 1: "The people who advise you on corporate life should have actually lived it."
- **Why it matters:** The client's core frustration is advice that doesn't translate to reality. They've been burned by theory that didn't work in their actual company, with their actual boss.
- **Proof point:** Ina has worked across companies of every size, in every function from admin to VP/Interim Head, in one of the most fast-moving environments (IT/Cyber Security).
- **In her words:** "Ein Personaler, der ist drin. Der wird mit dem Problem konfrontiert."

### Pillar 2: "You're not stuck because you're not capable. You're stuck because nobody showed you how it really works."
- **Why it matters:** Removes self-blame. Reframes the stuckness from personal failure to system opacity — which Ina can decode.
- **Proof point:** Sales leaders who became managers and discovered Excel-filled days. Controllers who ended up in strategy meetings instead of the numbers they love.
- **In her words:** "Dass das gar nicht an ihnen liegt und ihrem Know-how, sondern dass viele interne Mechanismen dafür verantwortlich sind."

### Pillar 3: "If you want to move, you have to take responsibility for the move."
- **Why it matters:** Self-selecting filter. Ina works with people who have the will to act — not people waiting for someone else to fix it.
- **Proof point:** The transformation Ina delivers is ultimately about ownership: "wieder Verantwortung für sich und sein Leben zu übernehmen."
- **In her words:** "Wenn ich was im Leben erreichen will, muss ich es selbst in die Hand nehmen."

### Pillar 4: "Speed matters. Clarity shouldn't take years."
- **Why it matters:** Her clients don't have patience for slow processes — they're busy, they're tired, and they want results.
- **Proof point:** Intuition paired with 22+ years of experience enables faster pattern recognition. "Wir können relativ schnell Resultate generieren."
- **In her words:** "Ich kann den Shortcut bieten."

---

## TOP 5 PROBLEMS & SOLUTIONS

**Problem 1:** "I've achieved a lot — but I don't know what I want anymore."
- **Her solution:** Status analysis that goes beneath the surface: not "what do you want to do" but "what have you actually been good at and loved, that got buried."
- **What makes it different:** She can see what the person has done through the lens of how organisations value it — which they often can't see themselves.
- **The transformation:** They rediscover their own competence and realise it's more transferable and more valuable than they thought.

**Problem 2:** "I'm so burned out I can't think straight."
- **Her solution:** She creates the container for the head to clear — fast, practical sessions that don't add to the noise.
- **What makes it different:** No lengthy questionnaires. Intuition-led but experience-anchored. "Sehr intuitiv, aber einfach Intuition gepaart mit Erfahrungen."
- **The transformation:** From paralysis back to motion. From "I can't see anything" to "I know what I'm doing next."

**Problem 3:** "I want to move into leadership / freelance / my own business — but I don't actually know what it involves."
- **Her solution:** She shows them what the role, the transition, or the structure actually requires — from the inside out.
- **What makes it different:** She's been in those rooms. She's managed those leaders. She knows what the job actually is, not what the job description says.
- **The transformation:** They make the move with eyes open — or they decide it's not the move they actually want, before they make a costly mistake.

**Problem 4:** "I've tried coaching before and it didn't work."
- **Her solution:** Zero theory. No buzzwords. No personality tests that lead nowhere. Real, specific, actionable advice mapped to how their actual industry and organisation works.
- **What makes it different:** She's not working from a methodology she learned on a certification course. She's working from 22+ years of being inside the problem.
- **The transformation:** They get answers that actually apply to their situation — not answers that sound good in a workshop.

**Problem 5:** "I feel like the best years are behind me / there's nothing new left."
- **Her solution:** She calls out the belief. Shows them what they have that they've stopped seeing. Reframes their experience as an asset — not a limitation.
- **What makes it different:** She can see what they've built through an HR executive's eyes. She knows how the market values it — often far more highly than they do.
- **The transformation:** From "I've seen it all" to "I haven't started the most interesting chapter yet."

---

## EMOTIONAL LANDSCAPE

### What drives them to act:
- **Identity:** "I want to be seen as someone who decides their own path — not someone who waits."
- **Achievement:** "I want to finally do the thing I know I'm capable of."
- **Relief:** "I want to stop carrying this feeling that something is wrong, that I'm wasting something."
- **Connection:** "I want to feel like myself again — the version that actually wants things and goes after them."

### What blocks them:
- **Fear barrier:** "What if I make the wrong decision again?" → Underneath: fear of wasting more time, of confirming they don't know themselves
- **Resource barrier:** "I can't afford to take time out / invest money right now" → Real issue: they're not sure it will work, so the cost feels high
- **Belief barrier:** "At this stage in my career, you can't really change direction" → Story they've absorbed from the environment around them
- **Timing barrier:** "Now's not the right time — let me just get through this quarter" → Has been the answer for three years

**The bridge:**
Ina's directness and insider credibility short-circuits the fear — because she's seen hundreds of people at exactly this point, knows what they're thinking before they say it, and can show them specifically why this situation is not unique and is solvable. The speed of her process also removes the time-cost barrier: this doesn't have to be a years-long journey.

---

## BRAND VOICE GUIDELINES

**Voice attributes:**

1. **Direct** — Says the thing plainly. No warming-up, no softening. Do: "Here's what's actually happening." Don't: "Well, it's complex and there are many perspectives to consider..."

2. **Warm** — Genuine care for the person, not the process. Do: Make them feel seen and understood before challenging them. Don't: Clinical, transactional, or cold even when being sharp.

3. **Insider** — Speaks with the authority of someone who has been inside. Do: Use specific corporate situations, real dynamics, named patterns. Don't: Speak in theory or from frameworks alone.

4. **No-nonsense** — Cuts what doesn't serve. Do: Short, specific, actionable. Don't: Long wind-ups, excessive caveating, polished marketing language.

5. **Umsetzungsstark** — Oriented toward action and results. Do: End every conversation with something concrete. Don't: Leave things open-ended or philosophical.

**Words to use:**
Klarheit — Verantwortung — Insider-Know-how — Mechanismen — Shortcut — Macher — Pragmatisch — Resultate — Konkret — Entscheidung treffen — Durchsetzung — Ehrlich — Schnell — Praktisch

**Words to avoid:**
Transformation — Journey — Empower — Leverage — Unlock — Holistic — Ecosystem — Navigate — Synergy — Ganzheitlich — Potenzial entfalten — Augenhöhe (overused in German coaching) — any language that sounds like a personal development brochure
