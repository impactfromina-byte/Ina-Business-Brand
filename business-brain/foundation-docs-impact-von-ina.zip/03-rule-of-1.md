━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
BUSINESS AUTHORITY FOUNDATION
Rule of 1
Client: Ina Spuling · Impact von Ina · June 2026
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# RULE OF 1
## Ina Spuling

---

## THE ONE FOCUS

- **One Avatar:** Marcus — the senior expert who built everything he was supposed to, and now doesn't know what he actually wants
- **One Problem:** A career built on expectations rather than choice — now running out of runway and momentum
- **One Solution:** Surface → Decode → Move (clarity → insider knowledge → concrete action)
- **One Outcome:** They own their next chapter — and they know how to execute it

---

## ONE AVATAR: Marcus

Marcus is 42. He's been good at his job for twenty years. He's delivered — consistently, reliably, sometimes brilliantly. He might be a senior sales leader, a finance expert who ended up managing a team, or a specialist who built their whole career in one department of one kind of company. From the outside, everything looks fine. He's earning well. He has respect. People come to him when things are on fire.

But privately, something has gone quiet. The ambition that used to pull him forward is still there — he can feel it — but it has nowhere to go. He's overworked. He's stopped looking up. He hasn't updated his LinkedIn in three years. He tells himself he'll think about what's next "when things calm down." They don't calm down.

He's tried the books. He took a workshop once. His company sent him on a leadership programme that was well-intentioned and completely useless for where he actually is. He considered a career coach, found someone with a nice website, had two sessions, and stopped because the advice felt generic. None of it spoke to the system he was actually operating inside.

**The turning point trigger:**
A restructuring at his company. A colleague who got the promotion he deserved. A physical symptom — burnout creeping in. Or simply: a morning where he looked at his calendar for the week and felt nothing. That's when he starts looking.

**Their internal monologue:**
"I've done everything right. So why does this feel so wrong? Is this it — is this just what work is at this stage? I'm not the kind of person who just... accepts that. But I don't know where to go from here. I've tried to think my way through this alone and I keep going in circles. And I'm too tired to even look properly. Maybe I'm just not as ambitious as I thought. No. That's not it. I know that's not it."

---

## ONE PROBLEM: THE VILLAIN

The problem is not Marcus. The villain is the system he was never taught to see — and the silence around it.

**External:** A career that was built on other people's expectations, in a system whose rules were never explained, reaching a point where the next step is genuinely unclear — and none of the available options feel like *his*.

**Internal:** The exhaustion of performing without direction. The creeping feeling that time is passing and something is being wasted. The specific frustration of being competent and stuck at the same time.

**Philosophical:** "Someone who has spent twenty years building real expertise shouldn't have to make their next career decision completely blind — without understanding the system they're navigating."

**The Villain Statement:**
"The real problem in Marcus's story is a corporate system that rewards performance but teaches nothing about how decisions actually get made — which shows up as being qualified and stuck at the same time, makes him feel like the problem is him when it isn't, and represents the unfair truth that the people who've contributed the most are often the least equipped to navigate their own next chapter."

---

## ONE SOLUTION: 3-STEP PLAN

**Step 1 — Surface (Status Analysis):**
The first thing that happens is a real conversation — not a questionnaire, not a personality test. Ina digs into what they've actually built, what they've actually loved, and what's actually in the way. She asks the questions that nobody else thought to ask. The output: clarity on what they want — not what they think they should want.

**Step 2 — Decode (Insider Map):**
This is where the corporate insider access comes in. Together they map the real landscape — how the decision they want to make actually works inside the system. What does "becoming a leader" actually look like day-to-day? How does a promotion really get made? What do companies actually look for when they're hiring at this level? What are the shortcut moves that most people don't know exist? Ina doesn't guess. She knows.

**Step 3 — Move (Execution with Accountability):**
From clarity and insider knowledge, they build the actual plan — the application, the positioning, the approach, the conversation, the timing. And they execute it. Not eventually. Now.

---

## ONE OUTCOME

**Tangible:** A concrete next move — offer accepted, promotion landed, freelance business started, founding decision made, or direction confirmed — with the plan that got them there.

**Emotional:** The feeling of being in control of their own story again. Relief. The energy that comes back when someone stops carrying the weight of an unresolved decision.

**Identity:** From "high achiever who somehow got stuck" to "person who takes ownership of their path — no matter what the system throws at them."

**Outcome Statement:**
"After working with Ina Spuling, Marcus will have made — and landed — a concrete next move he chose for himself, feel the clarity and energy that comes from finally being in the driver's seat, and see himself as someone who doesn't wait for permission to decide what comes next."

---

## THE DEEPER EMOTIONAL FOUNDATION

Ina has spent 22+ years inside rooms that most people only ever see from the outside. She has coached leaders at their most vulnerable, managed the humans behind restructurings, and watched the same avoidable mistakes happen again and again — not because people weren't capable, but because nobody ever showed them how the system actually worked. That knowledge is not academic. It was built across more than 100 different leaders, more than 1,000 people coached, in one of the most demanding environments in business: IT and Cyber Security, where staying still meant falling behind. She doesn't coach from a textbook. She coaches from the inside.

---

## 14 HOOKS

### POSITIVE HOOKS (Paint the Win)

1. You don't need more ambition. You need someone who can show you how the system actually works.
2. What if your next career chapter was the most interesting one — and you haven't started it yet?
3. The moment you stop waiting to feel ready is the moment things start moving.
4. Your 20 years of experience are worth more than you think. You just need someone who can read them clearly.
5. There is a shortcut. It's called working with someone who's already been inside.
6. Over 1,000 people coached — from the inside of the companies making the decisions. That's a different kind of advice.
7. The version of you that's competent, clear, and moving again — is not far from where you are now.

### NEGATIVE HOOKS (Call Out the Pain)

1. The people advising you on your corporate career have mostly never worked inside one.
2. Your company is not responsible for your development. The sooner you accept that, the faster you move.
3. You're not stuck because you're not capable. You're stuck because nobody showed you how it really works.
4. Every quarter you say "when things calm down" is a quarter you don't get back.
5. Generic coaching didn't work because generic advice doesn't apply to your specific company, your specific boss, your specific situation.
6. Career books and personality tests can't tell you why you didn't get that promotion. Someone who's been in that room can.
7. You already know what's wrong. You don't need more thinking. You need a plan.

---

## 7-PART BRAND STORY

### 1. A Character
Marcus closes his laptop at 8pm on a Tuesday. He's been in three strategy meetings, reviewed two performance reports, and answered 47 emails. His work is good. He knows it's good. But somewhere between the second and third meeting, a thought surfaced and stayed: *Is this still what I want?* Not the company — the direction. Not the role — the future. He's 42, he's built something real, and he genuinely doesn't know what he wants to do next. And that scares him more than any performance conversation ever did.

### 2. Has a Problem
The problem isn't visible. He's performing. His team respects him. His boss thinks he's solid. But internally, the drive that used to pull him forward has lost its target. He's tried to think his way through it — and keeps going in circles. He picked up a career book that was full of frameworks and none of his reality. He's considered coaching but has a nagging suspicion he'll get more theory from someone who's never sat inside a company like his, who doesn't know how decisions actually get made, who can't tell him what his next move will actually feel like from the inside. So he keeps waiting. For clarity to arrive. For the right moment. For something to change.

### 3. Meets a Guide
Ina Spuling has been where Marcus works — not as a visitor, but as the HR executive who ran the decisions, coached the leaders, and managed the humans behind every restructuring. Over 22 years, across companies from startups to enterprise, across industries from tech to professional services, she has seen more than 100 leaders at exactly Marcus's crossroads. She knows what's happening to him before he finishes explaining it. And she can tell him the truth — specifically, practically, without jargon — because she was inside.

### 4. Who Gives Them a Plan
First, they surface what's actually there — the real ambitions, the buried skills, the things Marcus stopped saying out loud because nobody asked. Then Ina decodes the system: what Marcus's next move actually looks like from the inside, where the real leverage is, and what the shortcut is that most people never find because they're working from the outside. Then they move — together, with a specific plan, specific language, specific action — until the decision is made and landed.

### 5. And Calls Them to Action
**Direct CTA:** Book a first conversation. Walk away with more clarity than you've had in months — or don't pay.
**Transitional CTA:** Follow for the insider knowledge that nobody in your company will tell you to your face.

### 6. That Helps Them Avoid Failure
Every quarter Marcus waits is a quarter that doesn't count toward the chapter he actually wants. The longer the decision stays unresolved, the more energy it takes just to carry it — and the less energy he has for doing the actual work. The longer he relies on generic advice, the more time he wastes on approaches that don't apply to his real situation, his real industry, his real company culture. And the longer he tells himself "it's fine," the more the version of him that actually wanted something starts to feel like a long time ago.

### 7. And Ends in Success
Marcus doesn't just get the next job. He gets the right next move — the one he chose, the one he understood before he made it, the one he knew how to execute because someone showed him how the system actually worked. He moves from the treadmill to the driver's seat. He stops performing for other people's plans and starts building his own. Months later, he says the same thing most of Ina's clients say: "I wish I'd done this years ago." He didn't need more ambition. He needed one person who could cut through the noise and show him what was actually possible — and how to go get it.

---

## WHY / WHO / HOW

**WHY:** "We exist because smart, capable people are being failed by advice that was never built for where they actually are — and nobody should have to navigate a complex system completely blind."

**WHO:** High performers — senior professionals, experts, leaders — who have achieved a lot and no longer know what they want to achieve next, or who know exactly what they want and can't figure out how to get there inside a system that was never explained to them.

**HOW:** "Unlike generic career coaches who've studied companies from the outside, Ina works from the inside — because she spent 22+ years in the rooms where the decisions get made. That means the advice is specific, the shortcuts are real, and the plan actually works in the organisation the client is actually in."
